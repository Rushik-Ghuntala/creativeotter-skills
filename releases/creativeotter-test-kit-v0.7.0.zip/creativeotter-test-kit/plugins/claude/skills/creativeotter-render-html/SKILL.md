---
name: creativeotter-render-html
description: "Render HTML/CSS layouts as PNG images or short CSS motion graphics as MP4 through an enabled CreativeOtter renderer. Use for title animations, kinetic text and exact code-based designs."
---

# Render layouts and motion graphics

CreativeOtter adaptation, 2026-11-06. Follow [the runtime contract](references/runtime-contract.md).

Use for HTML/CSS, designed motion, animated title cards or kinetic text. Ordinary generated imagery belongs to generate-image; filmed-looking footage belongs to video planning. The renderer uses Chromium and FFmpeg, without fal.ai. A skill installation alone does not enable it: inspect `get_capabilities.html_rendering` and the tools exposed in this chat. The backend release is opt-in; if unavailable, offer a source draft without claiming rendered output or spending image credits.

Build one self-contained composition with exact copy, dimensions and timing. Put the visible markup in `html` and styles/keyframes in `css`; style tags, style attributes, scripts, external URLs, web fonts, audio and arbitrary HyperFrames/GSAP JavaScript are unsupported. Use CSS keyframes for motion. For existing images, supply up to four owned ready `asset_ids` and refer to them as `<img src="asset:UUID">`; never publish private assets. Use even dimensions from 128 to 1920 pixels. Output is `png` at time zero or silent `mp4` lasting 1–10 seconds at 12 or 24 fps. Keep animation timing independent of wall-clock time and ensure important copy is visible at the intended moment.

For a non-spending estimate, call `prepare_render` with title, format, html, css, width, height, duration_seconds, fps, asset_ids and a fresh UUID request_key. Report only the returned CreativeOtter credit amount. For the user's explicit creation request, continue directly with `render_design` using its returned render_id; no extra approval is needed. Reuse that ID when recovering an uncertain response. Never authorize rendering with an image quote or create another render to recover saving/status problems. Production prices must come from the live quote; test prices are not a permanent customer policy.

Use `get_render` for progress and reopening the existing result. Ready means succeeded, saved and charged. The CreativeOtter panel previews the PNG or plays the MP4, refreshes private links and provides Download. `list_renders` finds saved designs by title; reopening or downloading spends no generation credits. Keep routine replies to one or two friendly sentences without IDs, routing details or technical timestamps. Do not claim a finished download from a URL alone. Failure releases reserved credits; an uncertain save remains pending for recovery.
