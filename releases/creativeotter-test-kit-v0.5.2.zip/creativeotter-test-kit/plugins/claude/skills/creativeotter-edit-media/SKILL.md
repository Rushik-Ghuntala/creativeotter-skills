---
name: creativeotter-edit-media
description: "Edit existing video or audio with CreativeOtter without regenerating it: trim, cut and reorder chosen moments, resize or reframe, caption, transcribe, clean speech, extract frames, add or mix audio, burn a logo watermark, compose images and clips, or add an intro/outro. Use when the source footage should be kept; use generation skills for invented or transformed footage and create-reels to pick highlights."
---

> CreativeOtter adaptation, 2026-11-01. Before using this workflow, read [the runtime contract](references/runtime-contract.md). Prefer suitable native engines, but require a CreativeOtter credit quote and paid execution claim directly on explicit user request before native tools. Missing billing stops generation. Provider-specific steps below apply only to enabled CreativeOtter API fallback, with current schemas and bound quotes, starting requested images without extra browser approval. Native execution follows its own host schema; inherited examples do not establish availability or pricing.


# Edit Existing Media



Read [shared execution guidance](references/workflow-basics.md) once per task before using tools. It covers existing authorization, model discovery, bound quotes and direct requested execution, imports, and recovery.

Turn supplied footage or audio into a finished derivative. Apply the requested edits with sensible defaults and no settings questionnaire. Keep the original asset unchanged.

## Pick only the operations you need

| Requested change | Tool and key limits |
| --- | --- |
| Shorten a video to one range | `trim_video`: set `start_time` explicitly, including zero, and either `end_time` or `duration`. |
| Cut, reorder, or reframe several chosen moments | `cut_and_reframe_video`: see [Multi-cut edits](#multi-cut-edits). |
| Resize or make a vertical version | `scale_video`: even dimensions and an explicit `mode`. `crop` is a center crop, `pad` keeps the full frame, `stretch` distorts. No subject tracking. |
| Burn captions | `add_subtitles`: transcribes the video itself and fits the font, size, and placement to the frame and language. See [Captions](#captions). |
| Get a transcript or find a passage | `transcribe`: exactly one of `audio_url` or `video_url`. |
| Clean a noisy recording | `isolate_audio`: keep and compare the original; cleanup can change speech. |
| Get still frames | `extract_frames`: check the schema for first/last/sampling controls. |
| Put narration or music on a clip | `add_audio_to_video`: see [Audio](#audio). |
| Join clips or audio files in order | `merge_media` with `video_urls` or `audio_urls`. |
| Burn a logo or copyright mark onto a finished video | `overlay_images` with a transparent image. `remove_background` can prepare a logo. |
| Build a video from existing timed images, clips, and optional audio | `stitch_clips`. It never generates footage; invented footage goes to `generate_video`. |
| Add an intro, outro, or both | See [Intros and outros](#intros-and-outros). |
| Upscale or remove a background | `upscale_image` / `upscale_video` (older clients: `upscale_media`) or `remove_background`. Upscalers come from `list_models({ category: "upscale" })`; each model's `get_model_params` settings go in `extras`. |

Read [assembly guidance](references/media-assembly.md) before any `merge_media`, `add_audio_to_video`, `overlay_images` or `stitch_clips` call. Older clients that list `operation` on `merge_media` and lack the other three tools: follow the fallback line there.

Route elsewhere: `creativeotter-generate-video` for invented footage or a generative change to the source; `creativeotter-create-reels` when the agent must pick highlights from long footage; `creativeotter-render-html` only when the user explicitly wants HTML or HyperFrames rendering. A caption request alone does not select HTML. For an exact text watermark, `render_html_image` with `transparent_background: true` can make the PNG for `overlay_images`.

## Workflow

1. Reuse the known asset or import the source through [platform-upload.md](references/platform-upload.md). Establish duration, aspect ratio, audio, and burned-in text from metadata and playback; do not invent measurements.
2. Run the smallest edit chain. Trim a user-given range directly. Transcribe first only if text or timing is needed to choose cuts.
3. Finish cuts and merges first, then resize to the final framing, then burn captions. Use a center crop only when the subject stays visible; otherwise pad or ask about the framing tradeoff.
4. Resolve each queued job with `check_job` before passing its result on. On failure, follow [job-recovery.md](references/job-recovery.md) and resume from the last completed derivative.
5. Burn captions last, following [Captions](#captions). Do not translate captions unless asked.
6. Check final length, framing, speech, caption sync and safe areas, and audio. Name and tag the result, and state any check you could not do.

For "make this a captioned vertical clip": reuse the footage, trim only if a shorter clip was asked for, resize with an explicit mode, then add captions. No model discovery or generation is needed.

## Captions

`add_subtitles` transcribes the video, detects the language, and chooses the font, size, line breaks, and a safe position for the frame. The defaults are white, readable on every aspect ratio and script, and keep emoji. Leave every styling input out unless the user asked for it. Set `language` only when the spoken language is known.

- **Look:** `preset` is `clean` (default), `highlight` (the spoken word in colour), `bold_pop` (large uppercase, three words at a time), `box` (dark box behind the text), `word_box` (a box on the spoken word), `one_word`, `reveal` (words appear as they are spoken), or `cinematic` (small and light). Set one only when the user describes that look.
- **Let the user choose:** `interactive: true` opens a card with the video, a demo of every look on it, and the price. The user can also set the position, size, and colours there. Nothing is rendered or charged until they pick a look and confirm in the card. Use it when the user wants to see or choose the style. After the call, tell them to pick in the card; do not call `add_subtitles` again for that video.
- **Known wording:** provide `script` when the user has the text that is spoken; timing still comes from the audio, and a script that does not match the speech is ignored. Provide `captions` (SRT, WebVTT, or a JSON list of `{start, end, text}` in seconds) when they have timed captions, including a translation they asked for; this skips transcription.
- **Names and jargon:** `terms: ["WonderZap"]` gives the transcriber the right spellings and adds one credit. `corrections: [{ "from": "wonder zap", "to": "WonderZap" }]` replaces a phrase after transcription.
- **Fix a finished result:** call `add_subtitles` with the same `video_url`, `fix_job_id` set to the job ID of the captioned video, and `corrections` and/or a different `preset`, `position`, `font_size`, or colours. Use a current bound quote; no fixed rate or entitlement is established here. The user can also do both themselves in the result card: edit the lines in its Text tab, or change the look, position, size, and colours in its Style tab. Never run `add_subtitles` on an already captioned video to fix it: the old captions stay underneath.
- **Fonts:** omit `font_name` unless the user names a font. A name is looked up among the workspace's brand theme fonts and uploaded fonts first, then Google Fonts. `font_url` takes a font file directly (TTF, OTF, WOFF, or WOFF2).

```text
add_subtitles({ video_url: "<video-url>", interactive: true })
add_subtitles({ video_url: "<video-url>", fix_job_id: "<captioned-job-id>", corrections: [{ from: "wonder zap", to: "WonderZap" }] })
```

## Multi-cut edits

Use `cut_and_reframe_video` when the user has chosen the moments (or `creativeotter-create-reels` has) and wants them cut, reordered, or reframed in one render. It does not pick highlights, transcribe, or track faces. If the tool is missing or returns "not configured", say so. Do not fake an exact multi-cut edit with a chain of lossy trims.

Read [the cut-and-reframe contract](references/edit-contract.md) before building input.

1. The source must be a video asset in this workspace. Keep an unchanged source URL and a source-timed transcript. Inspect metadata and frames; do not invent sizes, word times, or coordinates.
2. Choose safe boundaries. Listen around each edge when you can. Avoid clipped consonants, breaths, and cut-off reactions. Prefer a natural gap, keep enough lead-in and tail, and end on a short release without entering the next word. The renderer does not extend ranges. Do not remove every pause or change what someone meant.
3. Set the requested width and height (1080×1920 is only the default). Use `pad` when position is uncertain. Use `center_crop` only after checking the subject stays in frame. For `crop`, give an even rectangle at the output aspect ratio, with static coordinates or keyframes set from real observations. If a speaker leaves the crop, revise the path or pad; never stretch or guess.
4. Captions are optional. Pass real source-timed words; the tool remaps them after the cuts and burns them last. With only sentence timing, render the cuts first and run `add_subtitles` on the result. Never fabricate word alignment. Use plain captions for overlapping speakers or right-to-left text unless you can review karaoke visually.
5. Submit one call per output. Save the job ID and the exact edit plan. After a timeout, poll the existing job; do not resubmit blindly.
6. Check every splice with about 1.5 seconds of context on each side, the first and last words, crop continuity, caption spelling and sync, and audio. Technical checks do not prove the edit reads well. Fix only identified faults; do not rerender speculatively.

## Intros and outros

Get the bookend segments, then concatenate them around the main video.

- **Supplied clips:** import and use them.
- **HTML title cards:** only when the user asks for HTML, HyperFrames, or code-rendered cards, or accepts that option when you offer it for exact text, fonts, and logos. Render them with `creativeotter-render-html`. An intro/outro request alone does not authorize `render_html_video`.
- **Generated cinematic bookend:** use `creativeotter-generate-video`. To match the look, `extract_frames` from the main video and pass the frame as a style reference.

1. Establish the main video's URL, size, aspect ratio, frame rate, audio, and platform.
2. Use the requested copy, logo, duration, and audio. Ask only about missing copy; do not invent a slogan or call to action. Keep bookends short.
3. Make segments at the main video's size and frame rate. Resolve and inspect each one.
4. Merge in playback order. Set `canvas_video_index` to the main video's zero-based index and `video_fit: "pad"` to keep mismatched frames whole, unless cropping is authorized.

```text
merge_media({
  video_urls: ["<intro-url>", "<main-video-url>", "<outro-url>"],
  canvas_video_index: 1,
  video_fit: "pad",
  pad_color: "black"
})
```

Omit a bookend that was not requested. Joining videos is a hard cut: no dissolves, crossfades, or audio carried across the join. If the main audio must continue under a bookend or fade across a cut, say so before making segments.

## Audio

- `add_audio_to_video` replaces the clip's audio by default and ends at the shorter input. Check both durations first; do not silently shorten the video to fit a voiceover.
- `audio_mode: "mix"` keeps the clip's own sound and layers the new track over it, at the video's full length. Set `original_volume` and `added_volume` (0–1); about 0.3 keeps music under speech.
- `stitch_clips` layers one audio track over the clips at full level, and the output can run past the last clip. Use it when the added audio should extend beyond the picture.
- `merge_media` with `audio_urls` joins files end to end; it does not layer them.
- Audio joins can crossfade: `crossfade_seconds` (0–30, try 5 for ambient music) overlaps adjacent tracks and shortens the output by that much per join, and `normalize_loudness: true` evens their levels first. Video joins never crossfade.
- There is no ducking or volume automation. Say which operation is missing before creating assets that cannot be assembled as asked.

## Limits

- A public YouTube, Google Drive, or social video page can go straight to `transcribe` as `video_url`. It is not a source for trimming, resizing, or subtitles; import the actual file for those.
- `add_subtitles` already transcribes. Add a separate `transcribe` job only for a transcript the user wants or for choosing cuts.
- Every paid processing operation needs a supported quote/reservation route. If quoting is unavailable, stop paid execution instead of calling an unquoted edit. Do not present a partial estimate as the total.
