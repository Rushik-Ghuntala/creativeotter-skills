> CreativeOtter adaptation, 2026-11-01. [Runtime contract](../runtime-contract.md) governs execution. This inherited creative/technical guide is not a current model catalog, price list, API schema or product-policy promise.

# Additional video models

Use this guide for an explicitly selected model outside the primary guides. Always fetch get_model_params for that exact model; the notes below describe the local integration, not every upstream capability. Read [reference production](reference-production.md) and [Review handling](review.md). Do not infer capability from a similar model name or transplant its reference tokens.

| Model | Input and prompting guidance |
| --- | --- |
| video/veo-3.1, video/veo-3.1-fast | Text, literal first frame or supported first/last frames. Describe visible action and native dialogue/ambience separately. English is documented; other spoken languages are unverified. Check `get_model_params` and use [spoken languages](spoken-languages.md) for those languages. Check duration/resolution combinations and generate_audio in the live schema. Do not invent multimodal reference arrays. |
| video/grok-imagine-1.5 | Literal first frame or image references, not both. Reference images use zero-based <IMAGE_0>, <IMAGE_1> tokens. Current route accepts up to seven images, not video/audio reference arrays. State identity and composition roles separately. |
| video/flux-3 | Images are ordered or timed keyframes, not generic identity references. extras.keyframes entries contain image_url and optional at_s; either timestamp every entry or omit all timestamps. Do not mix extras.keyframes with separate frame/reference fields. One video_urls source selects extension. Describe motion between compatible anchors. |
| video/minimax-h3 | This is not H3 Max. Read its current schema and Usage for provider-normalized image/video/audio citations, resolution and reference limits. Separate literal frames from references. Assign each reference a role; do not borrow Max's pricing or resolution values. |
| video/hailuo-02-pro | Text or supported first/last-frame animation. Describe subject motion, camera and physical continuity. Do not assume native audio or arbitrary reference arrays. |
| video/hailuo-2.3-fast | Requires an opening image. Describe what moves after that image; do not promise text-only or end-frame support. |
| video/happyhorse-1.0 | Literal first frame or ordered image references, not both. Current reference syntax is character1 through character9, matching array order. Check spoken-language support and do not treat visual references as voice cloning. |
| video/heygen-avatar-4 | Direct HeyGen Avatar IV talking photo: a clear face in image_url. extras.audio_url supplies exact speech and overrides prompt/voice; otherwise use extras.voice_id from HeyGen's catalog (default Lucian). 720p/1080p only, auto framing, expressiveness and motion_prompt controls. Old fal voice names are unsupported. Use finished speech, not a private cloning source. |
| video/minimax-h3-max-lip-sync | Talking photo driven by finished speech: `image_url` plus `extras.audio_url`. One generation for one talking face within duration limits. For unsupported or unverified native-dialogue languages, follow [spoken languages](spoken-languages.md); multiple requested shots use consistent images from the same character references, per-shot speech, then concatenation. |
| video/heygen-lipsync | Use a current bound quote; no fixed rate or entitlement is established here. |
| video/sync-3 | Recommended for general existing-video lip sync, with supplied or embedded audio and automatic or manual speaker selection. Lip-syncs one finished clip to prepared speech: one clip in `video_urls`, one speech file in `audio_urls`. `prompt` is required but unused. Match the clip and speech lengths first (trim or extend). For several faces, set `extras.options.active_speaker_detection` (auto-detect is the default; provide `frame_number` and `coordinates` to pick a face). Charged per second of output. |
| video/heygen-agent | Prompt-led presenter workflow with model-specific config. Read current config structure, voice/avatar options and output behavior before submission; do not apply Avatar 4 fields by analogy. |

## Explicit-request-only routes

Do not proactively recommend or route to LTX or DreamActor. If explicitly requested and currently available:
- video/ltx-2.3-fast: inspect extras.operation for retake, extend, reframe or audio_to_video. Do not invent a top-level operation selector. Validate the driving source, timing and operation-specific media combination.
- video/dreamactor-v2: motion transfer uses a Character image and one driving video for body motion, facial expression and lip movement. It is not a generic reference-based text-to-video model. Inspect the current driving-video mapping and limits.

For a newly available or explicitly requested legacy model not listed here, use the live model schema and Usage. Do not substitute a recommended model silently or revive hidden models in discovery recommendations.
