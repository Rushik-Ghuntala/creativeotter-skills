> CreativeOtter adaptation, 2026-11-01. [Runtime contract](../runtime-contract.md) governs execution. This inherited creative/technical guide is not a current model catalog, price list, API schema or product-policy promise.

# Design a new voice

Use `design_voice` when the user wants a new synthetic voice from a description and has no recording to clone: "make me a new voice", "give my character a voice", a fictional narrator. It is not cloning, so no speaker recording or cloning consent is needed. Never design a voice to imitate a real person.

## Where each voice comes from

- A consenting speaker's recording → `clone_voice` (creativeotter-clone-voice).
- A description → `design_voice`.
- A stock catalog voice → `update_character({ id, voice_model, voice_id })`. This saves the choice on the Character without generating anything.

## Preview

Prepare the audition text using [speech localization](speech-localization.md). Every Hebrew word must have full niqqud for every provider, including ElevenLabs and Google, as well as Fish. Apply the same rule when speaking with the saved voice.

Call `design_voice({ prompt, text, provider, character_id })`:
- `prompt` (20 to 1,000 characters): age, accent, timbre, pace, attitude and use. Describe the sound, never a real person's name or identity.
- `text` (100 to 1,000 characters): one or two of the Character's real lines, about 200 characters. Omit it only when no script exists yet.
- `provider`: `"elevenlabs"` (default), `"google"`, or `"fish"`. For Google or Fish, add `language_code`, such as `"he-IL"`.
- `character_id`: the Character that should get the voice, when known.

Every preview returns three auditions. Let the user pick one. In ChatGPT the Voice Studio card plays them and saves the choice; read it back with `list_characters` rather than saving again.

## Save

`design_voice` only creates the auditions. Save the pick by passing the audition's `preview_id` as `voice_preview_id`:

- Existing Character: `update_character({ id, voice_preview_id })`. For an avatar, use the SAME Character `id` so its image and voice stay together.
- New voice-only Character: `create_character({ title, voice_preview_id })`.

A save keeps the Character's other voices and makes this one preferred for its speech model. If the save hits the limit, relay the tool's message and link, and offer `replace_voice_option_id` to replace a saved designed voice from the same provider. Never quote plan prices.

Use `update_character` and `create_character` when available. Older clients that expose only `manage_character` can still send `voice_preview_id` and `replace_voice_option_id` to it. If its cached schema omits the audition field, use the available `design_voice({ action: "save", preview_id, character_id })` compatibility route, or `character_name` for a new Character. Do not generate new auditions just to save an approved one.

## Speak

Call `generate_speech({ character_id, model, text })`:
- ElevenLabs design → `speech/elevenlabs-v4`.
- Google design → `speech/gemini-3.8-flash-tts`.
- Fish design → `speech/fish-drama-3`.

Provide `voice_option_id` to pick a saved voice that is not the preferred one; `list_characters` shows the options. Keep the same Character, model and settings for every line of a project.

## Fish design

With `provider: "fish"`, the description allows up to 2,000 characters and the audition text must be 1 to 150 characters. Use a current bound quote; no fixed rate or entitlement is established here. Defaults: `guidance_scale: 2`, `instruct_guidance_scale: 0`, `speed: 1`, `num_step: 32`; an optional seed is supported. Start with defaults. For Hebrew use `language_code: "he-IL"` and full niqqud on every spoken word.

```json
{"provider":"fish","prompt":"Warm Israeli female narrator, expressive modern Hebrew, clear diction and an easy conversational pace.","text":"שָׁלוֹם, אֵיזֶה כֵּיף שֶׁאַתֶּם כָּאן. הַיּוֹם נַתְחִיל בְּסִפּוּר קָטָן.","language_code":"he-IL"}
```

Fish candidate IDs are temporary. Save the selected CreativeOtter preview with `update_character({ id, voice_preview_id })`, or `create_character({ title, voice_preview_id })` for a new Character; this creates a private voice and a Drama 3 Character option. The Character retains its other model voices. Accepted saves with an unknown outcome must not be retried automatically.
