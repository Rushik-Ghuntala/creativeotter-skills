# CreativeOtter for ChatGPT web

This package contains all 21 skills and references the registered CreativeOtter remote app `asdk_app_6aed79fcb8bc819194e28fa8c7bb49dc`. It contains no direct MCP server launch/configuration, hooks or credentials.

Install or update it using ChatGPT's plugin archive controls, then connect the required CreativeOtter app and complete your own sign-in. The referenced app must be available in the target account/workspace. This ZIP does not register an app or grant access by itself. For another account without access to this app, create a custom remote MCP connection there and rebuild using its actual registered app ID.

A successful archive build is not proof of a live web install. Verify the uploaded plugin no longer has the laptop/Desktop only label and that its connection works in a new web chat. Test with: “Is my CreativeOtter account connected?” and “Show my latest saved CreativeOtter images. Don't create anything new.”

Source guidance: https://learn.chatgpt.com/docs/enterprise/plugin-management and https://developers.openai.com/plugins/build/plugins
